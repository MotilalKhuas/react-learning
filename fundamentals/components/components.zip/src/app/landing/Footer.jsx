function Footer(){
    const element = (
        <footer>
            <p>&copy; All rights reserved</p>
        </footer>
    );
    return element;
}

export default Footer;