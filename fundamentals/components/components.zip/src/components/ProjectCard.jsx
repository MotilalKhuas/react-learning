function ProjectCard(){
    return(
        <div className = "project-card">
            <figure className="img-wrapper">
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/58/Uber_logo_2018.svg/500px-Uber_logo_2018.svg.png" alt="Trulli"></img>
            </figure>
            <h3>Uber Clone Applicatoin</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime, iste repellat atque tempore illum quis porro iusto? Quo aliquid voluptatem aliquam cumque amet illo, fugit minus iste libero ab aspernatur.</p>
        </div>
    )
}

export default ProjectCard